#include <stdio.h>

int main(int argc, char *argv[]){
	//Oppgave 1.a) print argument
	printf("%s\n",argv[1]);
}















